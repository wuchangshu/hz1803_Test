#!/bin/bash
#1、增量导出ods_order：
sqoop job --delete bap_us_order
sqoop job --create bap_us_order -- import \
--connect jdbc:mysql://192.168.0.106:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table us_order \
--target-dir /qfbap/ods_tmp/ods_us_order/ \
--fields-terminated-by '\001' \
--check-column order_id \
--incremental append \
--last-value 0 \
#2、增量导出ods_cart
sqoop job --delete bap_cart
sqoop job --create bap_cart -- import \
--connect jdbc:mysql://192.168.0.106:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table cart \
--target-dir /qfbap/ods_tmp/ods_cart/ \
--fields-terminated-by '\001' \
--check-column cart_id \
--incremental append \
--last-value 0 \
#3、增量导出ods_order_delivery
sqoop job --delete bap_order_delivery
  sqoop job --create bap_order_delivery -- import \
  --connect jdbc:mysql://192.168.0.106:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
  --driver com.mysql.jdbc.Driver \
  --username root \
  --password 123456 \
  --table order_delivery \
  --target-dir /qfbap/ods_tmp/ods_order_delivery/ \
  --fields-terminated-by '\001' \
  --check-column order_id \
  --incremental append \
  --last-value 0 \
#4、增量导出ods_order_item
sqoop job --delete bap_order_item
sqoop job --create bap_order_item -- import \
--connect jdbc:mysql://192.168.0.106:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table order_item \
--target-dir /qfbap/ods_tmp/ods_order_item/ \
--fields-terminated-by '\001' \
--check-column order_id \
--incremental append \
--last-value 0 \
#5、增量导出ods_user_app_click_log
sqoop job --delete bap_user_app_click_log
 sqoop job --create bap_user_app_click_log -- import \
 --connect jdbc:mysql://192.168.0.106:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
 --driver com.mysql.jdbc.Driver \
 --username root \
 --password 123456 \
 --table user_app_click_log \
 --target-dir /qfbap/ods_tmp/ods_user_app_click_log/ \
 --fields-terminated-by '\001' \
 --check-column user_id \
 --incremental append \
 --last-value 0 \
#6、增量导出ods_user_pc_click_log
sqoop job --delete bap_user_pc_click_log
 sqoop job --create bap_user_pc_click_log -- import \
 --connect jdbc:mysql://192.168.0.106:3306/qfbap_ods?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
 --driver com.mysql.jdbc.Driver \
 --username root \
 --password 123456 \
 --table user_pc_click_log \
 --target-dir /qfbap/ods_tmp/ods_user_pc_click_log/ \
 --fields-terminated-by '\001' \
 --check-column user_id \
 --incremental append \
 --last-value 0 \

#run with args.eg: ./load_data.sh 2018-12-25
args=$1
dt=
if [ ${#args} == 0 ]
then
dt=`date -d "1 days ago" "+%Y%m%d"`
else
dt=$1
fi

#1. run sqoop job
echo "load full data by sqoop.starting...."
sqoop job -exec bap_us_order
sqoop job -exec bap_cart
sqoop job -exec bap_order_delivery
sqoop job -exec bap_order_item
sqoop job -exec bap_user_app_click_log
sqoop job -exec bap_user_pc_click_log
echo "load full data by sqoop.ended...."

#2. load data statments.
echo "run hive load data."
hive --database qfbap_ods -e "load data inpath '/qfbap/ods_tmp/ods_us_order/*' into table qfbap_ods.ods_us_order partition(dt=${dt})";
hive --database qfbap_ods -e "load data inpath '/qfbap/ods_tmp/ods_cart/*' into table qfbap_ods.ods_cart partition(dt=${dt})";
hive --database qfbap_ods -e "load data inpath '/qfbap/ods_tmp/ods_order_delivery/*' into table qfbap_ods.ods_order_delivery partition(dt=${dt})";
hive --database qfbap_ods -e "load data inpath '/qfbap/ods_tmp/ods_order_item/*' into table qfbap_ods.ods_order_item partition(dt=${dt})";
hive --database qfbap_ods -e "load data inpath '/qfbap/ods_tmp/ods_user_app_click_log/*' into table qfbap_ods.ods_user_app_click_log partition(dt=${dt})";
hive --database qfbap_ods -e "load data inpath '/qfbap/ods_tmp/ods_user_pc_click_log/*' into table qfbap_ods.ods_user_pc_click_log partition(dt=${dt})";
echo "run hive load data end."

